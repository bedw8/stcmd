from .mapa import Mapa

del mapa
