# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['stcmd', 'stcmd.maps']

package_data = \
{'': ['*']}

install_requires = \
['folium>=0.13.0,<0.14.0',
 'geopandas>=0.12.1,<0.13.0',
 'streamlit>=1.14.0,<2.0.0']

setup_kwargs = {
    'name': 'stcmd',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Benjamin',
    'author_email': 'bedw@bedw.me',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8, !=2.7.*, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*, !=3.5.*, !=3.6.*, !=3.7.*',
}


setup(**setup_kwargs)
